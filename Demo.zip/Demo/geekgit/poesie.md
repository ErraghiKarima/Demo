# Amis de la poésie !


> [**Code poetry** is literature that intermixes notions of classical poetry and computer code.
(extrait Wikipedia)](https://en.wikipedia.org/wiki/Code_poetry https://en.wikipedia.org/wiki/Code_poetry)


## Source Code Poetry Challenge 

Connaissez-vous le **source code poetry challenge** qui consiste à écrire un poème de manière à ce que :   

> The poetry must properly compile in any programming language. 

Quelques exemples de soumissions des années précédentes :

 <img src="http://www.sourcecodepoetry.com/file/2015/05/13/179070_151126888387332_1021759542_n_1.png" width="600">  
 
 <img src="http://www.sourcecodepoetry.com/file/2015/05/13/551939_151125001720854_1164601800_n_1.png" width="600">  


Pour en savoir plus, rendez-vous sur le site : http://www.sourcecodepoetry.com/  
et jetez un petit coup d'oeil sur le livre : [./code --poetry](https://leanpub.com/code-poetry ) <img src="https://s3.amazonaws.com/titlepages.leanpub.com/code-poetry/hero?1479665026" width="50">   


--

## Autre pratique, autre challenge : autre lien à proposer ?

