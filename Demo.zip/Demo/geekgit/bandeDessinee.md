# Bande dessinée & Développement logiciel



## Commit Strip


Connaissez-vous **Commit Strip**  ? Des webcomics sur la vie des codeurs ...

Quelques exemples :

<img src="http://www.commitstrip.com/wp-content/uploads/2013/11/Strips-_Old-650-final1.jpg" width="600">  
Extrait de : http://www.commitstrip.com/fr/2013/11/05/git-svn-ou/

<img src="https://www.commitstrip.com/wp-content/uploads/2017/03/Strip-Move-fast-break-things.jpg" width="600">  
Extrait de : http://www.commitstrip.com/fr/2017/03/10/anyone-can-be-wrong-sometimes/ 

<img src="https://www.commitstrip.com/wp-content/uploads/2017/02/Strip-Ou-sont-les-tests-unitaires-650-final.jpg" width="600">  
Extrait de : http://www.commitstrip.com/fr/2017/02/08/where-are-the-tests/

**La suite sur le site : http://www.commitstrip.com  
et/ou sur les comptes twitter  [@CommitStrip](https://twitter.com/CommitStrip) et [@CommitStrip_fr](https://twitter.com/CommitStrip_fr)**

--

## Autre lien à proposer ?
