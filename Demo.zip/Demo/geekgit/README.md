# Hello les geeks !

Pour commencer un peu de poésie par [ici](poesie.md)
  
Et quelques peintures par [là](peinture.md)

Des bandes dessinées [ici](bandeDessinee.md)
